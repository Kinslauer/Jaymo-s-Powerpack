The Last Lantern example for Minecraft 26.3.
Requires Jaymo's Kingdoms with the written-start system from PR #2153.
Use a disposable test world: copy this zip into its datapacks folder before starting a new life.
Choose Brought in from the dark on the last life-story page.
This pack overrides the original way_hut start definition so both shipped entries select this example.
It does not refill containers or reset a life already in progress.
Not tested in game. The gate is breakable in survival; it demonstrates tale progression.
